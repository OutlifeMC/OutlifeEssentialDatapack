#Lucky_He
#/data/minecraft/tags/functions/readme.txt

tick.json内的MC函数将在每一游戏刻执行一次。
The MC functions in "tick.json" will execute on each game tick.

#Lucky_He