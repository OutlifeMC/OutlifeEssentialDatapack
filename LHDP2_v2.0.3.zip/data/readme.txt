#Lucky_He
#/data/readme.txt

此处为命令空间目录。
Namespace directory here.

在游戏中MC函数的执行方式为：/function 命名空间:MC函数（带路径）
Using command "/function <namespace>:<MC function with directory>" to execute the MC function.

#Lucky_He