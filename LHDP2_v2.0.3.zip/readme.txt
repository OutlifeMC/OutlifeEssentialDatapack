#Lucky_He
#/readme.txt

这是一个由Lucky_He开发的数据包。
版本为v2。
本次数据包将提供英文翻译。
联系：QQ 673230244
This is a datapack developed by Lucky_He.
Version: v2.
We also provide English translations in these versions.
Some translations may be wrong, and we are sorry for the inconvenience brought to you.
Contact information:
QQ 673230244

#Lucky_He